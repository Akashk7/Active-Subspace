function y = forrester(x)

y =((x.*6-2).^2).*sin((x.*6-2).*2);

return

