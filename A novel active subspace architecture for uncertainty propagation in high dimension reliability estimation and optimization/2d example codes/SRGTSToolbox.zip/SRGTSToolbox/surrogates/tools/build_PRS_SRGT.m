function [srgtSRGTPRS, PRESSRMS_PRS, eXV_PRS, srgtOPTPRS] = build_PRS_SRGT(X,Y)
% polynomial response surface
polyTerms = {'Full','StepwiseSRGTS','ZeroIntercept'};

PRESSRMS_PRS_op = zeros(3,3);
for j = 1:3
    for i = 1:3
        prsoptions  = srgtsPRSSetOptions(X, Y, j, polyTerms{i});
        [PRESSRMS_PRS_op(i,j), ~] = srgtsCrossValidation(prsoptions);
    end
end

[best_polyTerms, best_order] = find(PRESSRMS_PRS_op == min(PRESSRMS_PRS_op(:)));
srgtOPTPRS  = srgtsPRSSetOptions(X, Y, best_order(1), polyTerms{best_polyTerms(1)});
srgtSRGTPRS = srgtsPRSFit(srgtOPTPRS);
[PRESSRMS_PRS, eXV_PRS] = srgtsCrossValidation(srgtOPTPRS);