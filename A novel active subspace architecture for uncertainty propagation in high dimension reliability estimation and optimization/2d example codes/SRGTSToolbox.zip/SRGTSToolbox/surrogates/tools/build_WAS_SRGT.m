function [srgtSRGTWAS, PRESSRMS_WAS, eXV_WAS, srgtOPTWAS] = build_WAS_SRGT(X,...
                                       srgtSRGTKRG, srgtOPTKRG, eXV_KRG,...
                                       srgtSRGTPRS, srgtOPTPRS, eXV_PRS,...
                                       srgtSRGTRBF, srgtOPTRBF, eXV_RBF)
% calculate CMatrix
eXVMatrix = [eXV_KRG eXV_PRS eXV_RBF];
CMatrix   = srgtsWASComputeCMatrix(X, eXVMatrix);

% options for WAS
srgtsOPTs   = {srgtOPTKRG  srgtOPTPRS  srgtOPTRBF};
srgtsSRGTs  = {srgtSRGTKRG srgtSRGTPRS srgtSRGTRBF};
WAS_Model   = 'OWSfull';
WAS_Options = CMatrix;

% WAS_Model   = 'PWS';
% p1 = [PRESSRMS_KRG_mcs, PRESSRMS_PRS_mcs, PRESSRMS_RBF_mcs];
% p2 = 0.05;
% p3 = -1;
% WAS_Options = {p1 p2 p3};

srgtOPTWAS  = srgtsWASSetOptions(srgtsOPTs, srgtsSRGTs, WAS_Model, WAS_Options);
srgtSRGTWAS = srgtsWASFit(srgtOPTWAS);

eXV_WAS=((srgtSRGTWAS.WAS_Weights(1)*eXV_KRG + ...
    srgtSRGTWAS.WAS_Weights(2)*eXV_PRS + ...
    srgtSRGTWAS.WAS_Weights(3)*eXV_RBF));

PRESSRMS_WAS = sqrt(sum((srgtSRGTWAS.WAS_Weights(1)*eXV_KRG + ...
    srgtSRGTWAS.WAS_Weights(2)*eXV_PRS + ...
    srgtSRGTWAS.WAS_Weights(3)*eXV_RBF).^2)/size(X,1));

