function [srgtSRGTRBF, PRESSRMS_RBF, eXV_RBF, srgtOPTRBF] = build_RBF_SRGT(X,Y)
% radial basis function
basisFuncs = {'MQ' ,'IMQ' ,'TPS','G'};
PRESSRMS_RBF_op = zeros(size(basisFuncs,2),10);
for i = 1:size(basisFuncs,2)
    for j = 1:10
        rbfOptions = srgtsRBFSetOptions(X,Y, @rbf_build, 1, basisFuncs{i}, j*0.1, 0);
        [PRESSRMS_RBF_op(i,j), ~] = srgtsCrossValidation(rbfOptions);
    end
end

[best_basis, best_sig] = find(PRESSRMS_RBF_op == min(PRESSRMS_RBF_op(:)));

if numel(best_basis)>1
    best_basis = best_basis(1);
    best_sig = best_sig(1);
end

srgtOPTRBF = srgtsRBFSetOptions(X,Y, @rbf_build, 1, basisFuncs{best_basis}, best_sig*0.1, 0);
srgtSRGTRBF = srgtsRBFFit(srgtOPTRBF);
[PRESSRMS_RBF, eXV_RBF] = srgtsCrossValidation(srgtOPTRBF);