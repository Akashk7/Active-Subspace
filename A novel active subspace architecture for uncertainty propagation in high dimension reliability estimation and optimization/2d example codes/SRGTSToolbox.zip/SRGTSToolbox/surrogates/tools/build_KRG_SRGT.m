function [srgtSRGTKRG, PRESSRMS_KRG, eXV_KRG, srgtOPTKRG] = build_KRG_SRGT(X,Y)
% kriging
regFuncs = {'@dace_regpoly0','@dace_regpoly1','@dace_regpoly2'};
corrFuncs = {'@dace_corrcubic','@dace_correxp','@dace_corrgauss',...
    '@dace_corrlin','@dace_corrspherical','@dace_corrspline'};
PRESSRMS_KRG_op = zeros(size(corrFuncs,2),size(regFuncs,2));

theta0 = 0.2*ones(1,size(X,2));
thetaL = 0.1*ones(1,size(X,2));
thetaU = 10*ones(1,size(X,2));
for j = 1:size(regFuncs,2)
    
    for i = 1:size(corrFuncs,2)
        krgOptions = srgtsKRGSetOptions(X,Y, @dace_fit,...
            str2func(regFuncs{j}) , str2func(corrFuncs{i}),theta0,thetaL,thetaU);
        
        [PRESSRMS_KRG_op(i,j), ~] = srgtsCrossValidation(krgOptions);
        
    end
    
end

[best_corr, best_reg] = find(PRESSRMS_KRG_op == min(PRESSRMS_KRG_op(:)));
if numel(best_corr)>1
    best_corr = best_corr(1);
    best_reg = best_reg(1);
end
srgtOPTKRG = srgtsKRGSetOptions(X,Y, @dace_fit,...
    str2func(regFuncs{best_reg}) , str2func(corrFuncs{best_corr}),theta0,thetaL,thetaU);
srgtSRGTKRG = srgtsKRGFit(srgtOPTKRG);
[PRESSRMS_KRG, eXV_KRG] = srgtsCrossValidation(srgtOPTKRG);